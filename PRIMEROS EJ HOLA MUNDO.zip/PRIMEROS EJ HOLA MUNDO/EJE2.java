
public class EJE2{

   public static void main(String[] args) {
       
                                                                           
        int A = 15;
        System.out.println(A + (A%2==0 ? " es par " : " es impar "));                                             
    }
}
    
    
    
 
